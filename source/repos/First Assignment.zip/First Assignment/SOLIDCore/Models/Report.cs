﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDCore.Models
{
    public abstract class Report
    {
        public abstract string GetContent();
    }
}
